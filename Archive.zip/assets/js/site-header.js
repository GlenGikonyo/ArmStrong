class SiteHeader extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <header class="w-100 header-con main-box br-1">
        <nav class="navbar navbar-expand-lg navbar-light">
          <a class="navbar-brand" href="index.html">
            <figure class="mb-0">
              <img src="assets/images/army.png" alt="logo-icon">
            </figure>
          </a>
          <button class="navbar-toggler collapsed" type="button" data-toggle="collapse"
            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            <span class="navbar-toggler-icon"></span>
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item mr-0">
                <a class="nav-link p-0" href="index.html">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link p-0" href="about.html">About</a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle p-0" href="#" id="navbarDropdown5" role="button"
                  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services</a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown5" role="menu">
                  <a class="dropdown-item" href="houseMoving.html">House Moving Services | Intercounty Relocation Services</a>
                  <a class="dropdown-item" href="officeMoving.html">Office Moving | Relocation</a>
                  <a class="dropdown-item" href="internationalMoving.html">International Moving and Relocation</a>
                  <a class="dropdown-item" href="recordsManagement.html">Records Management</a>
                  <a class="dropdown-item" href="secureStorage.html">Affordable Storage Service | Self Storage Nairobi</a>
                  <a class="dropdown-item" href="staffRelocation.html">Staff Relocation Services</a>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link p-0" href="our-clients.html">Our clients</a>
              </li>
              <li class="nav-item">
                <a class="nav-link p-0" href="faq.html">FAQs</a>
              </li>
              <li class="nav-item">
                <a class="nav-link p-0" href="contact.html">Contact</a>
              </li>
            </ul>
          </div>
          <div class="header-contact">
            <ul class="list-unstyled mb-0 d-flex align-items-center">
              <li class="d-flex align-items-center">
                <figure class="header-phone mb-0">
                  <img src="assets/images/call-icon.png" alt="call-icon" class="img-fluid d-inline-block">
                </figure>
                <div>
                  <a href="tel:+254 720 322 873" class="text-decoration-none cell-no">
                    <span class="number d-inline-block urbanist-font">+254 720 322 873</span>
                  </a>
                </div>
              </li>
              <li class="d-inline-block">
                <a href="index.html#get-quote" class="contact-btn d-inline-block">
                  Get a Quote <i class="fa-solid fa-angle-right ml-2"></i>
                </a>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <a class="whatsapp-float" href="https://wa.me/254728098375" target="_blank" rel="noopener noreferrer" aria-label="Chat with Armstrong Movers on WhatsApp" title="Chat with us on WhatsApp">
        <i class="fa-brands fa-whatsapp" aria-hidden="true"></i>
      </a>
    `;

    this.headerElement = this.querySelector('.header-con');
    this.handleScroll = () => {
      this.headerElement.classList.toggle('is-sticky', window.scrollY > 0);
    };
    this.updateReservedHeight = () => {
      const styles = window.getComputedStyle(this.headerElement);
      const marginTop = parseFloat(styles.marginTop) || 0;
      this.style.height = `${this.headerElement.offsetHeight + marginTop}px`;
    };

    this.updateReservedHeight();
    window.addEventListener('scroll', this.handleScroll, { passive: true });
    window.addEventListener('resize', this.updateReservedHeight);
    this.setActiveLink();
  }

  disconnectedCallback() {
    window.removeEventListener('scroll', this.handleScroll);
    window.removeEventListener('resize', this.updateReservedHeight);
  }

  setActiveLink() {
    let currentPage = window.location.pathname.split('/').pop();
    if (currentPage === '') currentPage = 'index.html';

    const navLinks = this.querySelectorAll('.nav-link, .dropdown-item');

    navLinks.forEach((link) => {
      const linkPage = link.getAttribute('href');
      link.classList.remove('active');

      if (linkPage === currentPage) {
        link.classList.add('active');

        const parentDropdown = link.closest('.dropdown');
        if (parentDropdown) {
          parentDropdown.querySelector('.dropdown-toggle').classList.add('active');
        }
      }
    });
  }
}

customElements.define('site-header', SiteHeader);